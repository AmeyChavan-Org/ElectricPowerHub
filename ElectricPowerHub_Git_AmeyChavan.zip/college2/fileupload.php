<!DOCTYPE html>
<html>
<head>
     <title>File Upload</title>

</head>
</html>
<form mrthod="POST" enctype="multipart/form-data">
<label>Title</label>
<input type="text" name="Title">
<label>File Upload </label>
<input type="File" name="file">
<input type="submit" name="submit"