<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>how to upload file in mysql database using php </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href=".\fileupload\bcs.css">
    </head>
<body>
    <form action="insert.php" method="post" enctype="multipart/form-data">    
    <form action="/update" method="post" autocomplete="on"> 
        <h2>Document Verification</h2>
        <label for="file_name">Filename:</label>
        <input type="file" name="anyfile" id="anyfile">
        <input type="submit" name="submit" value="Upload">
        <p><strong>Note:</strong> Only .jpg, .jpeg, .gif, .png formats allowed to a max size of 5 MB.</p>
    </form>
</body>
</html>