<?php
if (!isset($_SESSION)) {
    session_start();
}
$is_logged_in = isset($_SESSION['user']);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link -->

    <link rel="stylesheet" href="style.css">
</head>

<body>

    <!-- header section starts -->

    <header>

        <a href="" class="logo"><span>E</span>lectrizat</a>

        <div id="menu-bar" class="fas fa-bars"></div>

        <nav class="navbar">
            <a href="#home">HOME</a>
            <a href="#explore">EXPLORE</a>
          <!--  <a href="#save">SAVE</a> -->
            <a href="#services">SERVICES</a>
            <a href="#review">REVIEW</a>
            <?php
            if ($is_logged_in) {
            ?>
                <a href="logout.php">LOGOUT</a>
            <?php
            } else {
            ?>
                <a href="login.php">LOGIN</a>
                <a href="register.php">REGISTER</a>
            <?php
            }
            ?>
            <a href="fileupload/index.php #verification">VERIFICATION</a>
            <a href="#contact">ABOUT US</a>
        </nav>

        <div class="icons">
            <i class="fas fa-search" id="search-btn"></i>
            <a href="#"><i class="fas fa-user" id="login-btn"></i></a>
        </div>

        <form action="" class="search-bar-container">
            <input type="search" id="search-bar" placeholder="Search here....">
            <label for="search-bar" class="fas fa-search"></label>
        </form>

    </header>

    <!-- header section ends -->


    <!-- home section starts -->

    <section class="home" id="home">
        <div class="content">
            <h3>CHARGE FOR JOYFUL JOURNEY</h3>
            <p>Electric power is everywhere present in unlimited quantities and can drive the worls's machinery without the need of coal, oil, gas, or any other of the common fuels.</p>
            <a href="https://www.canva.com/design/DAE_pj_9YGA/keNZqNg6xH4rNOHvNDrVHA/view?utm_content=DAE_pj_9YGA&utm_campaign=designshare&utm_medium=link&utm_source=publishsharelink" class="btn">GET STARTED</a>
        </div>

        <div class="swiper image-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide"><img src="image4.jfif" alt=""></div>
                <div class="swiper-slide"><img src="slider2.jpeg" alt=""></div>
                <div class="swiper-slide"><img src="slider3.jpeg" alt=""></div>
                <div class="swiper-slide"><img src="image2.jfif" alt=""></div>
                <div class="swiper-slide"><img src="image5.jfif" alt=""></div>
                <div class="swiper-slide"><img src="image6.jfif" alt=""></div>
            </div>
        </div>

        <!-- image slider cdn link -->

    </section>
    <!-- home section ends -->


    <!-- explore Section starts -->

    <section class="explore" id="explore">

        <h1 class="heading">
            <span>E</span>
            <span>X</span>
            <span>P</span>
            <span>L</span>
            <span>O</span>
            <span>R</span>
            <span>E</span>
        </h1>

        <p>Enter your current location to explore your nearest electric Hub for electricity and other facilities.</p>

        <iframe src="https://www.google.com/maps/d/embed?mid=1ZP9BmzWXb7XcByZd7XXr_PfLSt49CGSq&ehbc=2E312F" width="600" height="450" style="border:0;width:100%;" allowfullscreen="" loading="lazy"></iframe>


    </section>
    <!-- explore section ends -->

    <!-- save section starts
    <section class="save" id="save">

        <h1 class="heading">
            <span>S</span>
            <span>A</span>
            <span>V</span>
            <span>E</span>
        </h1>

        <p>Glance your saved destionation to save time and get help faster. Save the hub destination you wish to visit in future for further services</p><br><br>


        <div class="box-container">

            <div class="box">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d21001.79265009436!2d2.282596638892557!3d48.85393726206896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701f7e8337b5%3A0xa2cb58dd28914524!2sEiffel%20Tower%2C%20Paris%2C%20France!5e0!3m2!1sen!2sin!4v1633702781943!5m2!1sen!2sin" width="30" height="100" style="border:0; width: 100%;" allowfullscreen="" loading="lazy"> </iframe>
                <p>136/4 Rosewilla Society</p>
                <div class="content">
                    <h1> <i class="fas fa-map-marker-alt"></i> INDIA</h1>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                </div>
            </div>

            <div class="box">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d21001.79265009436!2d2.282596638892557!3d48.85393726206896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701f7e8337b5%3A0xa2cb58dd28914524!2sEiffel%20Tower%2C%20Paris%2C%20France!5e0!3m2!1sen!2sin!4v1633702781943!5m2!1sen!2sin" width="30" height="100" style="border:0; width: 100%;" allowfullscreen="" loading="lazy"></iframe>
                <p>Koregoan Park Pune</p>
                <div class="content">
                    <h1> <i class="fas fa-map-marker-alt"></i> INDIA</h1>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                </div>
            </div>

            <div class="box">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d21001.79265009436!2d2.282596638892557!3d48.85393726206896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701f7e8337b5%3A0xa2cb58dd28914524!2sEiffel%20Tower%2C%20Paris%2C%20France!5e0!3m2!1sen!2sin!4v1633702781943!5m2!1sen!2sin" width="30" height="100" style="border:0; width: 100%;" allowfullscreen="" loading="lazy"></iframe>
                <p>Keshawnagar, Mundhwa</p>
                <div class="content">
                    <h1> <i class="fas fa-map-marker-alt"></i> INDIA</h1>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                </div>
            </div>

            <div class="box">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d21001.79265009436!2d2.282596638892557!3d48.85393726206896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701f7e8337b5%3A0xa2cb58dd28914524!2sEiffel%20Tower%2C%20Paris%2C%20France!5e0!3m2!1sen!2sin!4v1633702781943!5m2!1sen!2sin" width="30" height="100" style="border:0; width: 100%;" allowfullscreen="" loading="lazy"></iframe>
                <p>Jangali Maharaj Road, Deccan Pune</p>
                <div class="content">
                    <h1> <i class="fas fa-map-marker-alt"></i> INDIA</h1>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                </div>
            </div>

            <div class="box">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d21001.79265009436!2d2.282596638892557!3d48.85393726206896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e6701f7e8337b5%3A0xa2cb58dd28914524!2sEiffel%20Tower%2C%20Paris%2C%20France!5e0!3m2!1sen!2sin!4v1633702781943!5m2!1sen!2sin" width="30" height="100" style="border:0; width: 100%;" allowfullscreen="" loading="lazy"></iframe>
                <p>Chatturshingi Mandir, Pune</p>
                <div class="content">
                    <h1> <i class="fas fa-map-marker-alt"></i> INDIA</h1>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                </div>
            </div>

            <div class="box">
                <iframe src="https://www.google.com/maps/d/edit?mid=1ZP9BmzWXb7XcByZd7XXr_PfLSt49CGSq&usp=sharing" width="30" height="100" style="border:0; width: 100%;" allowfullscreen="" loading="lazy"></iframe>
                <p>J.W Marriott, S.B Road Pune</p>
                <div class="content">
                    <h1> <i class="fas fa-map-marker-alt"></i> INDIA</h1>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- save section ends -->
            
    <!-- services section starts -->

    <section class="services" id="services">

        <h1 class="heading">
            <span>S</span>
            <span>E</span>
            <span>R</span>
            <span>V</span>
            <span>I</span>
            <span>C</span>
            <span>E</span>
            <span>S</span>
        </h1>

        <div class="box-container">

            <div class="box">
                <i class="fas fa-charging-station"></i>
                <a href="https://mordorintelligence.com/industry-reports/electric-vehicle-power-inverter-market?gclid=Cj0KCQjwpcOTBhCZARIsAEAYLuWyMphv54aaQx8jSbKlXNGQvbq2VbVD9SVlUSA8LXX3nao6D2WGt0MaAtiQEALw_wcB">
                    <h3>Invest in EVs</h3>
                </a>
                <p>INVERTER MARKET - GROWTH, TRENDS, COVID-19 IMPACT, AND FORECASTS (2022-2027)</p>
            </div>
            <div class="box">
                <i class="fa fa-motorcycle"></i>
                <a href="https://shride.in/">
                    <h3> Rental Services</h3>
                </a>
                <p>Get EVs on Rent at affortable price.</p>
            </div>
            <div class="box">
                <i class="fas fa-door-open"></i>
                <a href="coming soon.html">
                    <h3>HOME SERVICE</h3>
                </a>
                <p>Waiting for your one call to be at your service.</p>
            </div>
                <div class="box">
                <i class="fas fa-battery-three-quarters"></i>
                <a href="equip.html">
                    <h3>ELECTRIC EQUIPMENTS</h3>
                </a>
                <p>Best of all you need on our journey.</p>
            </div>
        </div>
    </section>
    <!-- services section ends -->

    <!-- review section starts -->

    <section class="review" id="review">

        <h1 class="heading">
            <span>R</span>
            <span>E</span>
            <span>V</span>
            <span>I</span>
            <span>E</span>
            <span>W</span>
        </h1>

        <div class=" swiper review-slider">

            <div class="swiper-wrapper">

                <div class="swiper-slide">
                    <div class="box">
                        <img src="WhatsApp Image 2022-05-04 at 12.53.17 AM.jpeg" alt="">
                        <h3>Venkatesh kondwa</h3>
                        <h4>Data Analyst at datametica(Pune)</h4>
                        <p>Excellent use of  UI/UX design at graduation level! mostly students focus on basic management website development, but this guys come up with an startup idea & its really great.</p>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="far fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="box">
                        <img src="WhatsApp Image 2022-05-04 at 12.53.14 AM.jpeg" alt="">
                        <h3>Saiprasad Gardas</h3>
                        <h4>designer at Livspace(Pune)</h4>
                        <p>I like the part where a user can become a provider at the same time , and also it helps local people to be a part of this website</p>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="far fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="box">
                        <img src="WhatsApp Image 2022-05-04 at 1.05.18 AM.jpeg" alt="">
                        <h3>Sakshi Agrawal </h3>
                        <h4>Managing director </h4>
                        <p>Being an entrepreneur I know it takes great mind to come up with such idea and to make it practically possible! wish you all the best guys .  </p>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="far fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="box">
                        <img src="WhatsApp Image 2022-05-04 at 12.53.12 AM.jpeg" alt="">
                        <h3>Sunil kendre</h3>
                        <h4>Software Developer</h4>
                        <p>Create use of available resoures such as google "mymaps" so you don't have to pay for the it.</p>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="far fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="box">
                        <img src="WhatsApp Image 2022-05-04 at 1.10.53 AM.jpeg" alt="">
                        <h3>Tanmaya kale</h3>
                        <h4>Taj Miss Maharastra</h4>
                        <p>Excellent service with easy access to tours . It was a seamless experience and we could not have been happier with the results. We will use this website surely in coming future</p>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="far fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="box">
                        <img src="WhatsApp Image 2022-05-04 at 1.19.33 AM.jpeg" alt="">
                        <h3>Ajit kemdarne</h3>
                        <h4>Writer/Open mic</h4>
                        <p>just try to make an application of this website to gain more user , this start-up idea will surely work .</p>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="far fa-star"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- review section ends -->



    <!-- about us section starts -->
    <section class="contact" id="contact">

        <h1 class="heading">
            <span>A</span>
            <span>B</span>
            <span>O</span>
            <span>U</span>
            <span>T</span>

            <span>U</span>
            <span>S</span>
        </h1>

        <div class="row" style="  display: flex;
          flex-wrap: wrap;
          gap: 1.5rem;">

            <div class="image" style="   flex: 1 1 35rem;">
                <img src="logo3.jpg" alt="" width="100%">
            </div>

            <form action="" style="flex: 1 1 65rem;">
                <div class="inputbox">
                    <input type="text" required placeholder="Name">
                    <input type="email" required placeholder="Email">
                </div>
                <div class="inputbox">
                    <input type="number" required placeholder="Contact no.">
                    <input type="text" required placeholder="Subject">
                </div>
                <textarea placeholder="Review" name="" id="" cols="30" rows="10" style="width: 100%;"></textarea><br><br>
                <input type="SUBMIT" class="sub-btn" value="     Send Message" style="width: 100%;">
            </form>


        </div>
    </section>
    <!-- about us section ends -->

    <!-- footer section starts -->

    <section class="footer" id="footer">

        <div class="box-container">

            <div class="box">
                <h3>ABOUT US</h3>
                <p>We navigate and help user find the nearest location to the user to make their journey more joyful and happy without any trouble. Providing the best to the user is your main motto. We provide direct connection to the user and provider. Giving an opportunity to local people will be an advantage. Finding electricity is and providing them to the user is what makes this platform unique and convenient.</p>
            </div>
            <div class="box">
                <h3>BRANCH LOCATION</h3>
                <a href="">PUNE</a>
                <a href="">MUMBAI</a>
                <a href="">NASHIK</a>
                <a href="">KOLHAPUR</a>
                <a href="">NAGAR</a>
            </div>
            <div class="box">
                <h3>EASY LINKS</h3>
                <a href="#home">HOME</a>
                <a href="#explore">EXPLORE</a>
                <a href="#save">SAVE</a>
                <a href="#services">SERVICES</a>
                <a href="#review">REVIEW</a>
                <a href="abc.html">LOGIN</a>
                <a href="register.html">REGISTER</a>
                <a href="">ABOUT US</a>
            </div>

            <div class="icons">
                <h3 style="font-size: 1.5rem;">FOLLOW US ON</h3><br>
                <a href="https://m.facebook.com"><i class="fab fa-facebook"></i></a><br><br>
                <a href="https://www.instagram.com"><i class="fab fa-instagram"></i></a><br><br>
                <a href="https://www.twitter.com"><i class="fab fa-twitter"></i></a><br><br>
            </div>
        </div>

        <h1 class="credit">Created by <span> Hub team's[BG17] </span></h1>
    </section>
    <!-- footer section ends -->
    <!-- footer section ends-->










    <!-- script part -->

    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

    <script>
        var swiper = new Swiper(".image-slider", {
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto",
            coverflowEffect: {
                rotate: 0,
                stretch: 0,
                depth: 100,
                modifier: 2,
                slideShadows: true,
            },

            loop: true,
            autoplay: {
                delay: 2000,
                disableOnInteraction: false,
            },
        });

        let menu = document.querySelector('#menu-bar');
        let navbar = document.querySelector('.navbar');
        let searchBtn = document.querySelector('#search-btn');
        let searchBar = document.querySelector('.search-bar-container');

        menu.addEventListener('click', () => {
            menu.classList.toggle('fa-home');
            navbar.classList.toggle('nav-toggle');
        });

        searchBtn.addEventListener('click', () => {
            searchBtn.classList.toggle('fa-times');
            searchBar.classList.toggle('active');
        });


        window.onscroll = () => {
            menu.classList.remove('fa-home');
            navbar.classList.remove('nav-toggle');
            searchBtn.classList.remove('fa-times');
            searchBar.classList.remove('active');
        }

        var swiper = new Swiper(".review-slider", {
            spaceBetween: 28,
            loop: true,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            breakpoints: {
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 3,
                },
            },

        });
    </script>




</body>

</html>