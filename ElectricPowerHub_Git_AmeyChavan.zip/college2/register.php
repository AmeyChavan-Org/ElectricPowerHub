<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login.css">

    <!-- font awesome cdn link -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

</head>

<body>
    <div class="hero">
        <div class="form-box">
        <marquee behavior="" direction="right to left" style="font-size: 20px;">Document verification is compulsary for both user and provider</marquee>

            <!-- <div class="button-box">
                <div id="btn"></div>
                <button type="button" class="toggle-btn" onclick="login()">User</button>
                <button type="button" class="toggle-btn" onclick="register()">Provider</button>
            </div> -->
            <div class="social-icons">
                <img src="instagram-new (1).png" alt="">
                <img src="facebook-f.png" alt="">
                <img src="twitter.png" alt="">
            </div>
            <form id="login" action="backend/forms.php" method="POST" id="register" class="input-group">
                <input type="text" name="name" class="input-field" placeholder="Full Name" required>
                <input type="email" name="email" class="input-field" placeholder="Email-Id" required>
                <input type="password" name="password" class="input-field" placeholder="Enter Password" required>
                <input type="password" name="confirm" class="input-field" placeholder="Confirm Password" required>
                <select name="type" required>
                    <option value="">Select option</option>
                    <option value="provider">Provider</option>
                    <option value="user">User</option>
                </select>
                <input type="text" name="address" class="input-field" placeholder="Address" required>
                <input type="number" name="contact" class="input-field" placeholder="Contact" required><br><br>
                <a href="File upload in JavaScript/index.html"><button type="button" class="submit-btn">Document Verify</button></a> require<br>

                <!-- <input type="checkbox" name="terms" class="chech-bx"><span>I agree to the terms and conditions</span> -->


                <button type="submit" class="submit-btn">Register</button>
            </form>
        </div>
    </div>
</body>

</html>